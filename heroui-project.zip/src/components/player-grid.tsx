import React from "react";
import { Card, CardBody, CardFooter, Avatar } from "@heroui/react";

interface Player {
  id: number;
  name: string;
  position: string;
  number: number;
  country: string;
}

export const PlayerGrid = () => {
  const players: Player[] = [
    { id: 1, name: "Iker Casillas", position: "Goalkeeper", number: 1, country: "Spain" },
    { id: 2, name: "Sergio Ramos", position: "Defender", number: 4, country: "Spain" },
    { id: 3, name: "Pepe", position: "Defender", number: 3, country: "Portugal" },
    { id: 4, name: "Raúl González", position: "Forward", number: 7, country: "Spain" },
    { id: 5, name: "Cristiano Ronaldo", position: "Forward", number: 9, country: "Portugal" },
    { id: 6, name: "Kaká", position: "Midfielder", number: 8, country: "Brazil" },
    { id: 7, name: "Karim Benzema", position: "Forward", number: 11, country: "France" },
    { id: 8, name: "Xabi Alonso", position: "Midfielder", number: 14, country: "Spain" },
    { id: 9, name: "Marcelo", position: "Defender", number: 12, country: "Brazil" },
    { id: 10, name: "Gonzalo Higuaín", position: "Forward", number: 20, country: "Argentina" },
    { id: 11, name: "Álvaro Arbeloa", position: "Defender", number: 17, country: "Spain" },
    { id: 12, name: "Guti", position: "Midfielder", number: 14, country: "Spain" },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {players.map((player) => (
        <Card key={player.id} className="border border-divider">
          <CardBody className="overflow-visible p-0">
            <div className="flex justify-center pt-6 pb-2">
              <Avatar
                src={`https://img.heroui.chat/image/avatar?w=200&h=200&u=${player.id + 20}`}
                className="w-24 h-24 text-large"
                name={player.name}
              />
            </div>
          </CardBody>
          <CardFooter className="flex flex-col items-center pb-6">
            <h3 className="font-bold text-lg">{player.name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm text-default-500">{player.position}</span>
              <span className="text-xs px-1.5 py-0.5 bg-default-100 rounded-full">#{player.number}</span>
            </div>
            <span className="text-xs text-default-400 mt-1">{player.country}</span>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
};