import React from "react";
import { Icon } from "@iconify/react";
import { Divider } from "@heroui/react";

export const Footer = () => {
  return (
    <footer className="bg-content2 py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="flex items-center gap-2 mb-6 md:mb-0">
            <Icon icon="logos:real-madrid" className="h-12 w-12" />
            <div className="flex flex-col">
              <span className="text-xl font-bold">Real Madrid CF</span>
              <span className="text-xs text-default-500">La Liga 2009-2010</span>
            </div>
          </div>
          
          <div className="flex gap-4">
            <a href="#" className="rounded-full bg-content3 p-2 hover:bg-content4 transition-colors">
              <Icon icon="lucide:facebook" className="h-5 w-5" />
            </a>
            <a href="#" className="rounded-full bg-content3 p-2 hover:bg-content4 transition-colors">
              <Icon icon="lucide:twitter" className="h-5 w-5" />
            </a>
            <a href="#" className="rounded-full bg-content3 p-2 hover:bg-content4 transition-colors">
              <Icon icon="lucide:instagram" className="h-5 w-5" />
            </a>
            <a href="#" className="rounded-full bg-content3 p-2 hover:bg-content4 transition-colors">
              <Icon icon="lucide:youtube" className="h-5 w-5" />
            </a>
          </div>
        </div>
        
        <Divider className="my-6" />
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold mb-4">About</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">Club History</a></li>
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">Stadium</a></li>
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">Honours</a></li>
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">Management</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold mb-4">Teams</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">First Team</a></li>
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">Real Madrid Castilla</a></li>
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">Youth Academy</a></li>
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">Women's Team</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold mb-4">Seasons</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">2009-2010</a></li>
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">2008-2009</a></li>
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">2007-2008</a></li>
              <li><a href="#" className="text-sm text-default-500 hover:text-primary">All Seasons</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold mb-4">Contact</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <Icon icon="lucide:map-pin" className="h-4 w-4 text-default-500" />
                <span className="text-sm text-default-500">Santiago Bernabéu Stadium, Madrid</span>
              </li>
              <li className="flex items-center gap-2">
                <Icon icon="lucide:phone" className="h-4 w-4 text-default-500" />
                <span className="text-sm text-default-500">+34 91 398 43 00</span>
              </li>
              <li className="flex items-center gap-2">
                <Icon icon="lucide:mail" className="h-4 w-4 text-default-500" />
                <span className="text-sm text-default-500">contact@realmadrid.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <Divider className="my-6" />
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-xs text-default-500 mb-4 md:mb-0">
            © {new Date().getFullYear()} Real Madrid CF. All rights reserved. This is a fan-made website.
          </p>
          <div className="flex gap-4">
            <a href="#" className="text-xs text-default-500 hover:text-primary">Privacy Policy</a>
            <a href="#" className="text-xs text-default-500 hover:text-primary">Terms of Service</a>
            <a href="#" className="text-xs text-default-500 hover:text-primary">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};