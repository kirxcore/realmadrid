import React from "react";
import { Card, CardBody, CardHeader, Divider } from "@heroui/react";
import { Icon } from "@iconify/react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

export const SeasonStats = () => {
  const topScorers = [
    { name: "Cristiano Ronaldo", goals: 26 },
    { name: "Gonzalo Higuaín", goals: 24 },
    { name: "Karim Benzema", goals: 8 },
    { name: "Kaká", goals: 8 },
    { name: "Raúl", goals: 7 }
  ];

  const seasonResults = [
    { name: "Wins", value: 31 },
    { name: "Draws", value: 3 },
    { name: "Losses", value: 4 }
  ];

  const COLORS = ["#4ade80", "#93c5fd", "#f87171"];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader className="flex gap-3">
          <div className="flex flex-col">
            <p className="text-lg font-bold">Top Scorers</p>
            <p className="text-small text-default-500">La Liga 2009-2010</p>
          </div>
        </CardHeader>
        <Divider />
        <CardBody>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart
              data={topScorers}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="goals" fill="hsl(var(--heroui-primary))" />
            </BarChart>
          </ResponsiveContainer>
        </CardBody>
      </Card>

      <Card>
        <CardHeader className="flex gap-3">
          <div className="flex flex-col">
            <p className="text-lg font-bold">Season Results</p>
            <p className="text-small text-default-500">38 matches played</p>
          </div>
        </CardHeader>
        <Divider />
        <CardBody>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={seasonResults}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {seasonResults.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value} matches`, ""]} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </CardBody>
      </Card>

      <Card className="lg:col-span-2">
        <CardHeader className="flex gap-3">
          <div className="flex flex-col">
            <p className="text-lg font-bold">Season Overview</p>
            <p className="text-small text-default-500">La Liga 2009-2010</p>
          </div>
        </CardHeader>
        <Divider />
        <CardBody>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            <div className="flex flex-col items-center p-4 rounded-lg bg-content2">
              <div className="mb-2 rounded-full bg-primary/10 p-3">
                <Icon icon="lucide:trophy" className="h-6 w-6 text-primary" />
              </div>
              <span className="text-2xl font-bold">2nd</span>
              <span className="text-sm text-default-500">Final Position</span>
            </div>
            
            <div className="flex flex-col items-center p-4 rounded-lg bg-content2">
              <div className="mb-2 rounded-full bg-primary/10 p-3">
                <Icon icon="lucide:goal" className="h-6 w-6 text-primary" />
              </div>
              <span className="text-2xl font-bold">102</span>
              <span className="text-sm text-default-500">Goals Scored</span>
            </div>
            
            <div className="flex flex-col items-center p-4 rounded-lg bg-content2">
              <div className="mb-2 rounded-full bg-primary/10 p-3">
                <Icon icon="lucide:shield" className="h-6 w-6 text-primary" />
              </div>
              <span className="text-2xl font-bold">35</span>
              <span className="text-sm text-default-500">Goals Conceded</span>
            </div>
            
            <div className="flex flex-col items-center p-4 rounded-lg bg-content2">
              <div className="mb-2 rounded-full bg-primary/10 p-3">
                <Icon icon="lucide:star" className="h-6 w-6 text-primary" />
              </div>
              <span className="text-2xl font-bold">96</span>
              <span className="text-sm text-default-500">Points</span>
            </div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
};