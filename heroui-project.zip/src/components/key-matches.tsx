import React from "react";
import { Card, CardBody, CardFooter, Chip } from "@heroui/react";
import { Icon } from "@iconify/react";

interface Match {
  id: number;
  home: string;
  away: string;
  homeScore: number;
  awayScore: number;
  date: string;
  competition: string;
  isWin: boolean;
}

export const KeyMatches = () => {
  const matches: Match[] = [
    {
      id: 1,
      home: "Real Madrid",
      away: "Barcelona",
      homeScore: 0,
      awayScore: 2,
      date: "April 10, 2010",
      competition: "La Liga",
      isWin: false
    },
    {
      id: 2,
      home: "Real Madrid",
      away: "Valencia",
      homeScore: 6,
      awayScore: 3,
      date: "March 23, 2010",
      competition: "La Liga",
      isWin: true
    },
    {
      id: 3,
      home: "Sevilla",
      away: "Real Madrid",
      homeScore: 2,
      awayScore: 3,
      date: "October 4, 2009",
      competition: "La Liga",
      isWin: true
    },
    {
      id: 4,
      home: "Real Madrid",
      away: "Atlético Madrid",
      homeScore: 3,
      awayScore: 2,
      date: "November 7, 2009",
      competition: "La Liga",
      isWin: true
    },
    {
      id: 5,
      home: "Barcelona",
      away: "Real Madrid",
      homeScore: 1,
      awayScore: 0,
      date: "November 29, 2009",
      competition: "La Liga",
      isWin: false
    },
    {
      id: 6,
      home: "Lyon",
      away: "Real Madrid",
      homeScore: 1,
      awayScore: 0,
      date: "February 16, 2010",
      competition: "Champions League",
      isWin: false
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {matches.map((match) => (
        <Card key={match.id} className="border border-divider">
          <CardBody>
            <div className="flex justify-between items-center mb-4">
              <Chip
                size="sm"
                variant="flat"
                color={match.isWin ? "success" : "danger"}
              >
                {match.isWin ? "Win" : "Loss"}
              </Chip>
              <span className="text-xs text-default-500">{match.date}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <div className="flex flex-col items-start">
                <span className={`font-semibold ${match.home === "Real Madrid" ? "text-primary" : ""}`}>
                  {match.home}
                </span>
                <span className={`font-semibold ${match.away === "Real Madrid" ? "text-primary" : ""}`}>
                  {match.away}
                </span>
              </div>
              
              <div className="flex flex-col items-end">
                <span className="font-bold">{match.homeScore}</span>
                <span className="font-bold">{match.awayScore}</span>
              </div>
            </div>
          </CardBody>
          <CardFooter className="flex justify-between items-center pt-0">
            <div className="flex items-center gap-1">
              <Icon icon="lucide:trophy" className="h-3.5 w-3.5 text-default-500" />
              <span className="text-xs text-default-500">{match.competition}</span>
            </div>
            <div className="flex items-center gap-1">
              <Icon icon="lucide:calendar" className="h-3.5 w-3.5 text-default-500" />
              <span className="text-xs text-default-500">2009-2010</span>
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
};