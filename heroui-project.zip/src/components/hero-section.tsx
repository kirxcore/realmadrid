import React from "react";
import { Button } from "@heroui/react";
import { Icon } from "@iconify/react";

export const HeroSection = () => {
  return (
    <section className="relative h-[80vh] min-h-[600px] w-full overflow-hidden bg-black">
      <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/40 z-10"></div>
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: "url('https://img.heroui.chat/image/sports?w=1920&h=1080&u=madrid2010')",
          filter: "brightness(0.7)"
        }}
      ></div>
      
      <div className="container relative z-20 mx-auto h-full px-4 flex flex-col justify-center">
        <div className="max-w-3xl">
          <h1 className="mb-4 text-4xl md:text-5xl lg:text-6xl font-bold text-white">
            Real Madrid CF
            <span className="block text-2xl md:text-3xl mt-2 text-white/90">La Liga 2009-2010 Season</span>
          </h1>
          <p className="mb-8 text-lg text-white/80 max-w-2xl">
            The 2009-2010 season marked the beginning of a new era for Real Madrid with the return of Florentino Pérez as president and the arrival of superstars like Cristiano Ronaldo, Kaká, Karim Benzema, and Xabi Alonso.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button 
              color="primary" 
              size="lg"
              endContent={<Icon icon="lucide:chevron-down" />}
              onPress={() => {
                document.getElementById('squad')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Explore Squad
            </Button>
            <Button 
              variant="flat" 
              size="lg"
              color="default"
              className="text-white bg-white/20 backdrop-blur-sm"
            >
              Season Highlights
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};