import React from "react";
import { Icon } from "@iconify/react";
import { Button, Card, CardBody, Image, Divider } from "@heroui/react";
import { HeroSection } from "./components/hero-section";
import { PlayerGrid } from "./components/player-grid";
import { SeasonStats } from "./components/season-stats";
import { KeyMatches } from "./components/key-matches";
import { Footer } from "./components/footer";

export default function App() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-50 w-full border-b border-divider bg-background/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Icon icon="logos:real-madrid" className="h-10 w-10" />
            <span className="text-xl font-bold">Real Madrid CF</span>
          </div>
          <nav className="hidden md:block">
            <ul className="flex items-center gap-6">
              <li><a href="#squad" className="text-sm font-medium hover:text-primary">Squad</a></li>
              <li><a href="#stats" className="text-sm font-medium hover:text-primary">Statistics</a></li>
              <li><a href="#matches" className="text-sm font-medium hover:text-primary">Key Matches</a></li>
              <li><a href="#gallery" className="text-sm font-medium hover:text-primary">Gallery</a></li>
            </ul>
          </nav>
          <Button 
            size="sm" 
            color="primary" 
            className="hidden md:flex"
            endContent={<Icon icon="lucide:external-link" className="h-4 w-4" />}
            as="a" 
            href="https://www.realmadrid.com" 
            target="_blank"
            rel="noopener noreferrer"
          >
            Official Website
          </Button>
          <Button isIconOnly variant="light" className="md:hidden">
            <Icon icon="lucide:menu" className="h-6 w-6" />
          </Button>
        </div>
      </header>

      <main>
        <HeroSection />
        
        <section id="squad" className="py-16 bg-content1">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">2009-2010 Squad</h2>
            <PlayerGrid />
          </div>
        </section>
        
        <section id="stats" className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Season Statistics</h2>
            <SeasonStats />
          </div>
        </section>
        
        <section id="matches" className="py-16 bg-content1">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Key Matches</h2>
            <KeyMatches />
          </div>
        </section>
        
        <section id="gallery" className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8 text-center">Gallery</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((id) => (
                <Card key={id} className="overflow-hidden">
                  <CardBody className="p-0">
                    <Image
                      removeWrapper
                      alt={`Real Madrid 2009-2010 moment ${id}`}
                      className="w-full h-64 object-cover"
                      src={`https://img.heroui.chat/image/sports?w=600&h=400&u=${id}`}
                    />
                  </CardBody>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}